package com.example.raspisaniempt;

public class Item {

    String Den;
    String Para1;
    String Para2;
    String Para3;
    String Para4;
    String Para5;


    public Item(String Den, String Para1,String Para2,String Para3,String Para4,String Para5)
    {
        this.Den = Den;
        this.Para1 = Para1;
        this.Para2 = Para2;
        this.Para3 = Para3;
        this.Para4 = Para4;
        this.Para5 = Para5;
    }

    public String getDen(){
        return Den;
    }

    public void SetDen(String Den){
        this.Den = Den;
    }


    public String getPara1(){
        return Para1;
    }

    public void SetPara1(String Para1){
        this.Para1 = Para1;
    }



    public String getPara2(){
        return Para2;
    }

    public void SetPara2(String Para2){
        this.Para2 = Para2;
    }


    public String getPara3(){
        return Para3;
    }

    public void SetPara3(String Para3){
        this.Para3 = Para3;
    }


    public String getPara4(){
        return Para4;
    }

    public void SetPara4(String Para4){
        this.Para4 = Para4;
    }

    public String getPara5(){
        return Para5;
    }

    public void SetPara5(String Para5){
        this.Para5 = Para5;
    }

}