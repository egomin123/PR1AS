package com.example.raspisaniempt;

import android.view.View;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;


public class MyViewHolder extends RecyclerView.ViewHolder{

 TextView DenView, Para1View, Para2View, Para3View, Para4View, Para5View;

 public MyViewHolder(@NonNull View itemView){
        super(itemView);
     DenView = itemView.findViewById(R.id.Den);
     Para1View = itemView.findViewById(R.id.Para1);
     Para2View = itemView.findViewById(R.id.Para2);
     Para3View = itemView.findViewById(R.id.Para3);
     Para4View = itemView.findViewById(R.id.Para4);
     Para5View = itemView.findViewById(R.id.Para5);
    }
}
