package com.example.raspisaniempt;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        RecyclerView  recyclerView = findViewById(R.id.recyclerview);

        List<Item> items = new ArrayList<Item>();
        items.add(new Item("Понедельник", "Пара1","Пара2","Пара3","Пара4","Пара5"));
        items.add(new Item("Вторник", "Пара1","Пара2","Пара3","Пара4","Пара5"));
        items.add(new Item("Среда", "Пара1","Пара2","Пара3","Пара4","Пара5"));
        items.add(new Item("Четверг", "Пара1","Пара2","Пара3","Пара4","Пара5"));
        items.add(new Item("Пятница", "Пара1","Пара2","Пара3","Пара4","Пара5"));
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(new MyAdapter(getApplicationContext(),items));


    }
}