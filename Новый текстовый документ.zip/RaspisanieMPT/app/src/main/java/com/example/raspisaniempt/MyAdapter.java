package com.example.raspisaniempt;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;


public class MyAdapter extends RecyclerView.Adapter<MyViewHolder>{

Context context;
List<Item> items;

    public MyAdapter(Context context, List<Item> items) {
        this.context = context;
        this.items = items;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull  ViewGroup parent, int viewType){
        return new MyViewHolder(LayoutInflater.from(context).inflate(R.layout.item_view,parent,false));
    }

    @Override
    public void onBindViewHolder(@NonNull  MyViewHolder holder, int position){
    holder.DenView.setText(items.get(position).getDen());
    holder.Para1View.setText(items.get(position).getPara1());
    holder.Para2View.setText(items.get(position).getPara2());
    holder.Para3View.setText(items.get(position).getPara3());
    holder.Para4View.setText(items.get(position).getPara4());
    holder.Para5View.setText(items.get(position).getPara5());
    }

    @Override
    public int getItemCount(){
        return items.size();
    }
}
