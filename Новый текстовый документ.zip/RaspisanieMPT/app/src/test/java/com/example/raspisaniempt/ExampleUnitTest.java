package com.example.raspisaniempt;

import org.junit.Assert;
import org.junit.Test;

import static org.junit.Assert.*;


public class ExampleUnitTest {
    @Test
    public void addition_isCorrect() {
        assertEquals(2, 3 + 3);
    }

}